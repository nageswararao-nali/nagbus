<?php $this->load->view('website_template/header.php');//echo 'website/'.$folder.$body.'.php';exit;?>
<?php $this->load->view('website/'.$folder.$body.'.php');?>
<?php $this->load->view('website_template/footer.php');?>