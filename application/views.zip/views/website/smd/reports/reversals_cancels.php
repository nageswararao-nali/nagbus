<?php $this->load->view('website/smd/links_block.php')?>
<div class="row">
  <div class="col-md-7">
    <div class="panel panel-default mb20 project-stats table-responsive">
      <div class="panel-body">
      <h4 class="text-center">Revesals and Cancelations</h4>
     <div class="row">
      <div class="col-md-3">
      <input type="text" class="form-control" placeholder="User ID">
      </div>
      <div class="col-md-3">
      <input type="text" class="form-control" placeholder="Provider No">
      </div>
      </div>
        <table class="table">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Worker Name</th>
              <th>Contact</th>
            </tr>
          </thead>
          <tbody>
            <tr>
             <td>Id1</td>
              <td>Name1</td>
              <td>Worker Name1</td>
              <td>Contact</td>
            <tr>
              <td>Id2</td>
              <td>Name2</td>
              <td>Worker Name2</td>
              <td>Contact</td>
            </tr>
            <tr>
              <td>Id3</td>
              <td>Name3</td>
              <td>Worker Name3</td>
              <td>Contact</td>
            </tr>
            <tr>
              <td>Id4</td>
              <td>Name4</td>
              <td>Worker Name4</td>
              <td>Contact</td>
            </tr>
            <tr>
              <td>Id5</td>
              <td>Name5</td>
              <td>Worker Name5</td>
              <td>Contact</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>