<!--this page is not used in any where-->

<!--<div class="container-fluid">
<div class="col-md-12">
  <table class="table table-bordered table-striped" >
    <thead style=" font-size:12px; padding:0px;">
      <tr>
        <th>Date&amp;Time</th>
        <th> Order no.</th>
        <th> Mobile no./Subscriber id </th>
        <th> Operator</th>
        <th> Recharge/Bill pay amount <i class="fa fa-inr"></i></th>
        <th> Amount Paid <i class="fa fa-inr"></i></th>
        <th> Payment Status</th>
        <th> Recharge/Bill pay status </th>
        <th> Revised recharge status </th>
        <th> Operator service availability </th>
      </tr>
    </thead>
    <tbody>
    <tr>
    <td>21/8/2015&amp;1:00PM</td>
    <td>1</td>
    <td>7396395259</td>
    <td>uninor</td>
    <td>500</td>
    <td>450</td>
    <td>success</td>
    <td>success</td>
    <td></td>
    <td></td>
    </tr>
    </tbody>
  </table>
</div>
</div>
-->

<div class="row">
  <div class="col-md-offset-4 col-md-8">
    <div class="panel mb20 panel-default panel-hovered">
      <div class="panel-body">
      <div class="row">
        <div class="col-md-6">
          <h4>Order No.1156762386</h4>
          <p><span>RS.</span></p>
        </div>
        <div class="col-md-6 text-right">
          <p>21 AUG'15 &amp; 2:00PM</p>
        </div>
        </div>
        <hr>
        <div class="row">
        <div class="col-md-4">
        <p>Recharge of Airtel Mobile 9502901001</p>
        <span>Qty:1</span>
        </div>
        <div class="col-md-4 text-center">RS.</div>
        <div class="col-md-4 text-right">
        <button class="btn btn-success">Successs</button>
        </div>
        </div>
      </div>
    </div>
  </div>
</div>
