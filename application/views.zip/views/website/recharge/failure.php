<!--this page is not used in any where-->
<div class="row">
  <div class="col-md-10">
    <div class="panel panel-default panel-hovered panel-stacked mb30">
      <div class="panel-body">
        <div class="row">
          <div class="col-md-6" style="font-size:16px;">Your BSNL mobile no. 9999999999 process is failed.</div>
          <div class="col-md-offset-3 col-md-3">
            <button type="submit" class="btn btn-primary">Try Again</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
