<div class="col-md-6 col-md-offset-3">
  <div class="panel panel-default panel-hovered panel-stacked mb30">
    <div class="panel-heading text-center"><h3>Register Now</h3></div>
    <div class="panel-body">
      <form class="form-horizontal" id="booknow">
      <!--<div class="alert alert-success">
        <button type="button" class="close" data-dismiss="alert"> <span aria-hidden="true">×</span> </button>
        <div>Dear Customer, Thank you for booking an order on laabus. You are successfully registered.</div>
      </div>-->
          <div class="form-group">
            <label class="control-label">Name:<font color="red">*</font></label>
            <input class="form-control" type="text" placeholder="" required/>
          </div>
          <div class="form-group">
            <label class="control-label">Mobile:<font color="red">*</font></label>
            <input class="form-control" type="text" placeholder="" required/>
          </div>
        <div class="form-group">
            <label class="control-label">Email:<font color="red">*</font></label>
            <input class="form-control" type="text" placeholder="" required/>
          </div>
         <!--<div class="form-group">
            <label class="control-label">City:<font color="red">*</font></label>
            <input type="text" class="form-control" name="city" id="geocomplete" required/>
            <div class="map_canvas" style="display:none !important"></div>
          </div>
          <div class="form-group">
            <label class="control-label">Address:<font color="red">*</font></label>
            <input class="form-control" type="text" placeholder="" required/>
          </div>
          <div class="form-group">
            <label class="control-label">Pincode:<font color="red">*</font></label>
            <input class="form-control" type="text" placeholder="" required/>
          </div>-->
         <div class="clearfix right">
            <a href="" class="btn btn-success mr5" type="submit" id="button">Submit</a>
          </div>
      </form>
    </div>
  </div>
</div>