<?php $this->load->view('website/user/link_block.php')?>

<div class="col-md-12">
        <div class="panel panel-default panel-hovered panel-stacked mb30">
          <div class="panel-body">
            <div class="row text-center">
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/electrician"><img id="myImage" onclick="changebulb()" src="<?php echo base_url()?>images/bulboff.jpg" width="50" height="60" />
                  <p>Electrical</p></a>
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/plumber"><img id="tap" onclick="changetap()" src="<?php echo base_url()?>images/tapoff.jpg" width="50" height="60" /><p>Plumbing </p></a>
              </div>
              <div class="col-md-3">
               <a href="<?php echo base_url()?>Index/services/list_sp/computer_repair"><img class="imgthumb" src="<?=base_url()?>images/computerrepair.png" alt="computerrepair" width="70" height="60" /><p>Computer Repair</p></a>
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/laundry"><img class="imgthumb" src="<?=base_url()?>images/laundry.jpg" alt="laundry" width="70" height="60" /><p>Laundry</p></a> 
              </div>
            </div>
            <div class="row text-center" style="margin-top:15px">
            <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/carpenter"><img class="imgthumb" src="<?=base_url()?>images/carpenter1.jpg" alt="carpenter1" width="60" height="60" /><p>Carpenter</p></a>
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/beauty"><img class="imgthumb" src="<?=base_url()?>images/beauty.jpg" alt="beauty" width="100" height="60" /><p>Beauty</p></a> 
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/mobile_repair"><img class="imgthumb" src="<?=base_url()?>images/mobilerepair.jpg" alt="mobilerepair" width="70" height="60" /><p>Mobile Repair</p> </a>
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/pestcontrol"><img class="imgthumb" src="<?=base_url()?>images/pestcontrol.jpg" alt="pestcontrol" width="70" height="70" /><p>Pest Control</p></a>
              </div>
            </div>
            <div class="row text-center" style="margin-top:15px">
            <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/painting"><img class="imgthumb" src="<?=base_url()?>images/paint.png" alt="paint" width="70" height="70" /><p>Painting</p> </a>
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/fitness"><img class="imgthumb" src="<?=base_url()?>images/fitness.jpg" alt="fitness" width="70" height="60" /><p>Fitness</p></a> 
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/appliances"><img class="imgthumb" src="<?=base_url()?>images/appliances.jpg" alt="appliances" width="90" height="60" /><p>Appliances</p></a> 
              </div>
              <div class="col-md-3">
                <a href="<?php echo base_url()?>Index/services/list_sp/home_cleaning"><img class="imgthumb" src="<?=base_url()?>images/homeclean.jpg" alt="homeclean" width="90" height="60" /><p>Home Cleaning</p></a> 
              </div>
            </div>
           </div>
        </div>
      </div>