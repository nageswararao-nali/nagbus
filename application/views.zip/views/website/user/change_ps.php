<div class="page page-auth">
      <div class="auth-container">
        <div class="form-head mb20">
          <h1 class="site-logo h2 mb5 mt5 text-center text-uppercase text-bold"><a href="<?php echo base_url()?>">Laabus</a></h1>
      <h5 class="text-normal h5 text-center">Change Password</h5>
        </div>
        <div class="form-container">
          <form class="form-horizontal" action="javascript:;">
             <div class="form-group">
              <label class="col-md-4">Current Password</label>
              <div class="col-md-8">
              <input type="email"  class="form-control">
              </div>
            </div>
            <div class="form-group">
             <label class="col-md-4">New Password</label>
             <div class="col-md-8">
              <input type="email"  class="form-control">
              </div>
            </div>
            <div class="form-group">
            <label class="col-md-4">Confirm New Password</label>
            <div class="col-md-8">
              <input type="email"  class="form-control">
              </div>
            </div>
            <div class="btn-group btn-group-justified mb15">
          <div class="btn-group">
            <button type="button" class="btn btn-primary">Change Password</button>
          </div>
          <div class="btn-group">
            <button type="submit" class="btn btn-success">Cancel</button>
          </div>
        </div>
          </form>
        </div>
      </div>
    </div>
  
