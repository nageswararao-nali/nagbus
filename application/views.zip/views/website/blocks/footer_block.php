  <div class="row">
    <div class="col-md-12 panel-footer-info" style ="padding:20px;font-size:20px; margin-top:45px; margin-bottom:45px;">
      <div class="text-center">
        <h4 style="font-size:40px">Contact Us</h4>
        <!--<strong><i class="fa fa-phone pr-10" style="font-size:24px"></i> 9491170016</strong>--> </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-3">
      <div class="panel mb20 panel-default panel-hovered">
        <div class="panel-heading">
          <h4>Download App</h4>
          <p>Click on your preferred device</p>
        </div>
        <div class="panel-body" >
          <div class="row">
            <div class="col-md-6"> <i class="fa fa-android" style="font-size:25px;"></i><strong>Google play</strong> </div>
            <div class="col-md-6"> <i class="fa fa-apple" style="font-size:25px;"></i><strong>iTunes</strong> </div>
          </div>
          <div class="row">
            <div class="col-md-6"> <i class="fa fa-windows" style="font-size:25px;"></i><strong>Windows</strong> </div>
            <div class="col-md-6"> <i class="icon-blackberry" style="font-size:25px;"></i><strong>Blackberry</strong> </div>
          </div>
        </div>
      </div>
    </div>
    <div class="col-md-1 text-left"> <strong class="services" style="color: #F60">Flights</strong>
      <ul style="list-style:none; padding:0px">
        <li>One Way</li>
        <li>Round Trip</li>
        <li>Multi City / Stop Over </li>
      </ul>
    </div>
    <div class="col-md-1 text-left"> <strong class="services" style="color:#F60">Holidays</strong>
      <ul style="list-style:none; padding:0px">
        <li>Packages</li>
        <li>Long Weekend </li>
        <li>Travel Ideas </li>
        <li>Group Packages </li>
      </ul>
    </div>
    <div class="col-md-1 text-left"> <strong class="services" style="color:#F60">Cabs</strong>
      <ul style="list-style:none; padding:0px">
        <li>One way</li>
        <li>Round trip</li>
      </ul>
    </div>
    <div class="col-md-1 text-left"> <strong class="services" style="color:#F60">Services</strong>
      <ul style="list-style:none; padding:0px">
        <li>Electrical</li>
        <li>Plumbing</li>
        <li>Beauty</li>
        <li>Appliances</li>
        <li>Fitness</li>
        <li>Painting</li>
        <li>Carpenter</li>
      </ul>
    </div>
    <div class="col-md-1"> <strong class="services" style="color:#F60">Pay Bills</strong>
      <ul style="list-style:none; padding:0px">
        <li>Electricity</li>
        <li>Mobile</li>
        <li>DTH/Prepaid Mobile</li>
        <li>Insurance Premiums</li>
        <li>Landline&amp; Internet</li>
      </ul>
    </div>
    <div class="col-md-1 text-left"> <strong class="services" style="color:#F60">E-SHOP</strong>
      <ul style="list-style:none; padding:0px">
        <li>Electronics</li>
        <li>Men</li>
        <li>Women</li>
        <li>Baby&amp;kids</li>
        <li>Home&amp;Furniture</li>
        <li>Books</li>
        <li>Sports</li>
      </ul>
    </div>
    <div class="col-md-3 text-center"><i class="fa fa-map-marker" style="font-size:25px; color: #F00;"></i><strong>Varini Info Systems Pvt. ltd@ Hyderabad:</strong><br/>
      <!--302,
      sri kalki chambers, 
      opp.Reliance Fresh, <br/>
      Madinaguda, 
      Hyderabad-50.<br/>-->
      Email: info@varini.in </div>
  </div>
  <div class="row" >
    <div class="col-md-12">
      <div class="col-md-7 col-md-offset-5"> <a target="_blank" href="https://www.facebook.com/"><i class="fa fa-facebook" style="font-size:30px;"></i></a> <a target="_blank" href="https://twitter.com/?lang=en"><i class="fa fa-twitter" style="font-size:30px; color:#0CF;"></i></a> <a target="_blank" href="https://plus.google.com/"><i class="fa fa-google-plus" style="font-size:30px; color:#CD3C2E;"></i></a> <a target="_blank" href="https://in.linkedin.com/"><i class="fa fa-linkedin" style="font-size:30px; color:#337AB7;"></i></a> </div>
    </div>
  </div>
