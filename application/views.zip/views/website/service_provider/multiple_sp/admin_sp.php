<?php $this->load->view('website/service_provider/multiple_sp/links_block.php')?>

<div class="row">
  <div class="col-md-12">
    <input type="checkbox">
    Product I Can Sell. </div>
</div>
<div class="row">
  <div class="col-md-7">
    <div class="panel panel-default mb20 project-stats table-responsive">
      <div class="panel-body">
        <table class="table">
          <thead>
            <tr>
              <th>S.NO.</th>
              <th>Services</th>
              <th>Select</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Plumber</td>
              <td><input type="checkbox"/></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Electrician</td>
              <td><input type="checkbox"/></td>
            </tr>
            <tr>
              <td>3</td>
              <td>Computer Repair</td>
              <td><input type="checkbox"/></td>
            </tr>
            <tr>
              <td>4</td>
              <td>Carpenter</td>
              <td><input type="checkbox"/></td>
            </tr>
            <tr>
              <td>5</td>
              <td>Appliances</td>
              <td><input type="checkbox"/></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
