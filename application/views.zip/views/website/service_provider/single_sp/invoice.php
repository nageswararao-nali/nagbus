<?php $this->load->view('website/service_provider/single_sp/links_block.php')?>
<div class="row">
  <div class="col-md-11">
    <div class="panel mb20 panel-default panel-hovered">
      <div class="row">
        <div class="col-md-8">
          <div class="hedaing">
            <h1 style="padding-left:15px;"><b>INVOICE</b></h1>
          </div>
        </div>
        <div class= "mt10 col-md-4">
          <h4 style="padding-right:3px;"> Date: September 9th, 2015 </h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
          <h4 style="padding-left:15px;"><b>Invoice Number: </b> 1234567</h4>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4" style="padding-left:30px;">
          <h4> Varini Info Systems Pvt.Ltd.</h4>
            <p><b>302, Sri Kalki Chambers</b></p>
            <p><b>Opp, Reliance Fresh</b></p>
            <p><b>Madinaguda, Hyderabad-500049</b></p>
            <p><b> variniinfo@gmail.com</b></p>
        </div>
        <div class="col-md-2"> </div>
        <div class="col-md-2" style="padding-left:100px;">
          <h5> TO: </h5>
        </div>
        <div class="col-md-4">
          <h4> Varini Info Systems Pvt.Ltd.</h4>
            <p><b>302, Sri Kalki Chambers</b></p>
            <p><b>Opp, Reliance Fresh</b></p>
            <p><b>Madinaguda, Hyderabad-500049</b></p>
            <p><b> variniinfo@gmail.com</b></p>
        </div>
      </div>
      <div class="row" style="margin-top:50px;">
        <div class="col-md-12">
          <table class="table table-bordered">
              <tr>
                <th width="50%">Services</th>
                <th>% Wise</th>
                <th >Commision</th>
                <th>Total</th>
              </tr>
              <tr>
                <td>John</td>
                <td>Doe</td>
                <td>john@example.com</td>
                <td>Doe</td>
              </tr>
              <tr>
                <td>Mary</td>
                <td>Moe</td>
                <td>mary@example.com</td>
                <td>Doe</td>
              </tr>
              <tr>
                <td>July</td>
                <td>Dooley</td>
                <td>july@example.com</td>
                <td>Doe</td>
              </tr>
          </table>
        </div>
      </div>
      <div class="row">
        <div class="col-md-9"> </div>
        <div class="col-md-3">
          <div class="row">
            <div class="col-md-5">
              <h5><b> Grand Total</b> </h5>
            </div>
            <div class="col-md-4" style="text-center">
              <input type="text" style="height:30px; width:100px;" placeholder="RS. 5,00,000"/>
            </div>
          </div>
        </div>
      </div>
      <div class="row" style="margin-top:80px;">
        <div class="col-md-8"> </div>
        <div class="col-md-4">
          <h4> THANK YOU FOR YOUR BUSSINESS!</h4>
        </div>
      </div>
    </div>
  </div>
</div>
