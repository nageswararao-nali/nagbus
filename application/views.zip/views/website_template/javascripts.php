<?php if($this->uri->segment($this->uri->total_segments())){}?>
<!--<script src="<?php echo base_url()?>web_assets/scripts/jcryption.js"></script>-->