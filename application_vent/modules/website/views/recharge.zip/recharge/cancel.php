<div class="row">
  <div class="col-md-10">
    <div class="panel panel-default panel-hovered panel-stacked mb30">
      <div class="panel-body">
        <div class="row">
          <div class="text-center" style="font-size:16px;">Your order is successfully canceled. Your amount will be credit with in 2days.</div>
        </div>
      </div>
    </div>
  </div>
</div>
