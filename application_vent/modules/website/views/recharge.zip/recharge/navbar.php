<div class="row">
  <div class="col-sm-12">
    <div class="btn-group btn-group-sm navContainer"> 
      <!--    <a href="<?php echo base_url()?>Index/recharge/history" class="btn-tag btn-tag-info view-month waves-effect l">Your orders</a> <a href="<?php echo base_url()?>Index/recharge/history" class="btn-tag btn-tag-success view-month waves-effect l">Transactions</a> <a href="<?php echo base_url()?>Index/recharge/history" data-toggle="dropdown" class="btn-tag btn-tag-danger view-month waves-effect l">Wallet</a><a href="<?php echo base_url()?>Index/recharge/DTH" data-toggle="dropdown" class="btn-tag btn-tag-primary view-month waves-effect l">DTH</a> 
-->
        <ul style="margin-left:-30px;">
          <li style="display:inline; margin-right:10px;"><a href="<?php echo base_url('recharge')?>">Mobile</a> </li>
          <li style="display:inline; margin-right:10px;"> <a href="<?php echo base_url('recharge/DTH')?>">DTH</a></li>
          <li style="display:inline; margin-right:10px;"> <a href="<?php echo base_url('recharge/datacard')?>">DataCard</a></li>
          <li style="display:inline; margin-right:10px;"> <a href="<?php echo base_url('recharge/landline')?>">Landline</a></li>
          <li style="display:inline; margin-right:10px;"> <a href="<?php echo base_url('recharge/electricity')?>">Electricity</a></li>
        </ul>
    </div>
  </div>
</div>